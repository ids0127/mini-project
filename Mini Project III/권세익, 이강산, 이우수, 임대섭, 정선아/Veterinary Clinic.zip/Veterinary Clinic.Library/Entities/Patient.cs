﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Veterinary_Clinic.Library
{
    public partial class Patient
    {
        public string CompanionName { get; set; }
        public string EmployeeName { get; set; }
        public string BreedsName { get; set; }
        public string PhoneNumber { get; set; }
        public int SpeciesID { get; set; }
    }
}
